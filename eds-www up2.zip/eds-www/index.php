<!DOCTYPE html>
<html>
<head>
<title>Limbo</title>
</head>
<body>
<?php
$logo = "images/leopard.png" ;
$welcome = "Welcome to Limbo!" ;
echo "<h1>" . $welcome . "</h1>" ;
echo "<img border=\"0\" src=" . $logo . ">" ;
?>
</body>
</html>
