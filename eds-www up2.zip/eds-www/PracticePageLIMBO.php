<!DOCTYPE html>
<html>
    
    <head>
        
        <title>Welcome to Limbo!</title>
        <meta name="description" content="An interactive getting started guide for Brackets.">
        <link rel="stylesheet" href="PracticeforLIMBO.css">
    </head>
    <body>
        <button> Admin Login </button>
        <h1>Welcome to Limbo!</h1>
     
        <h2> ~Marist's Lost and Found Database~ </h2>
        
        
        <p>
           With Limbo, you can report items that you've lost or found on the Marist College campus. 
        </p>
        

     
        <h3>
             Report a...
        </h3>
        
        <button1 type="button">LOST ITEM</button1> 
    
        <button2 type="button">FOUND ITEM</button2>
       
        
        
        
        
   
        
       