<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="PracticeforLIMBO.css">
    <title> Update Lost/Found Item Tables </title>
</head>
  <head>
<style>  
    table {
    font-family: sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
</head>
    <h1> Update Lost Item Table </h1>
    
    
    <table>
  <tr>
    <th>Description</th>
    <th> Location </th>
    <th> Date Lost </th>
  </tr>
  <tr>
    <td>    </td>
    <td>    </td>
    <td>    </td>
  </tr>
  <tr>
    <td>    </td>
    <td>    </td>
    <td>    </td>
  </tr>
  <tr>
    <td>    </td>
    <td>    </td>
    <td>    </td>
  </tr>
  <tr>
    <td>    </td>
    <td>    </td>
    <td>    </td>
  </tr>
  <tr>
    <td>    </td>
    <td>    </td>
    <td>    </td>
  </tr>
  <tr>
    <td>    </td>
    <td>    </td>
    <td>    </td>
  </tr>
</table>   
    
 <button type="submit">Edit Table</button>
<button><a href="lost.php"> Lost something</a> </button>
    
    
