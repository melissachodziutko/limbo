<!DOCTYPE html>
<html>
<head>
<title>Hello</title>
</head>
<body>
<?php
echo "<h1> Hello World </h1>" ;
?>
</body>
</html>
