<?php
echo '<pre>';
echo 'LOADED EXTENSIONS:<br/>';
print_r(get_loaded_extensions());
echo '</pre>';
echo phpinfo();
?>