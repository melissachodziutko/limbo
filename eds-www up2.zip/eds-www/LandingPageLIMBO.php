<!DOCTYPE html>
<html>
    
    <head>
        
        <title>Welcome to Limbo!</title>
        <meta name="description" content="An interactive getting started guide for Brackets.">
        <link rel="stylesheet" href="PracticeforLIMBO.css">
    </head>
    <body>
        <!-- this would lead to adminlogin.html -->
		<form action="adminlogin.php" align = "left">
        <input type="submit" value="Admins" />
        </form>
        <h1>Welcome to Limbo!</h1>
     
        <h2> Marist's Lost and Found Database </h2>
        
        
        <p>
           With Limbo, you can report items that you've lost or found on the Marist College campus. 
        </p>
		
        
		<!-- lead to lost.html -->
        <form action="losttable.php">
        <input type="submit" value="Lost Something?" />
        </form>

		<!-- lead to found.html -->
        <form action="foundtable.php">
        <input type="submit" value="Found Something?" />
        </form>

        <form action="QuickLinksLIMBO.php">
        <input type="submit" value="Quick Links" />
        </form>
		
		
       
        </body>
        
        
        
   
        
       